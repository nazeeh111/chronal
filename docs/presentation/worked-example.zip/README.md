# Chronal current-source fictional-price replay

This archive contains the complete matching chronal/ Python source and native worked-run/ plan, fictional input, candidates, development/holdout results, manifests, CSVs and offline reports. All data and application code are original MIT material; preserve LICENSE. NumPy is separately installed under its BSD/dependency licenses. No market data, brokerage route, credentials or paid service is used.

Use an isolated Python 3.12+ environment with numpy==2.5.4 (requirements.lock); this exact NumPy lock requires Python>=3.12. This execution used CPython 3.14.10 on macOS ARM64; native records retain that identity. It is not the old example's Python 3.14.7 runtime.

Verify every archived byte: python3 check.py --hashes-only
Reconstruct the ledger and replay both regions: python check.py
This checks matching source fingerprint, plan/data/candidate/result/report identities, chronological fits, selection, cash/fills and net outcomes with the original strict verifier. It does not run the 12-replication research study. The included check.py inserts only its own source directory.

Open worked-run/development/report.html and worked-run/holdout/report.html directly in a browser. Reports are self-contained and work without a server. Their adjacent results.json, equity.csv and fills.csv stay available. Press / for commands, use help, choose a strategy/session, inspect account/model/execution, or export exact CSVs. Fresh reopening restores the saved experiment, not unsaved command history. No inspection command sends an order.

The plan freezes input.csv, metadata.json, candidates.json and plan.json inside worked-run/. Nested development/manifest.json and holdout/manifest.json bind each native region. SHA256SUMS.json separately hashes all archive files except itself. These hashes detect changes against the included records; they are not signatures or independent timestamps. CSV CRLF bytes are preserved exactly.

The frozen candidate trend60 gains 1.775% in development and loses 1.461% in its separate holdout; equal weight loses 4.528% on holdout. Each region starts a separate 100000-unit simulated account; cash persists across folds inside a region. Costs and cash constraints are part of the record. This one fictional path establishes no investable edge or physical execution accuracy. No future market or historical language-model skill is claimed.

Current source: https://github.com/nazeeh111/chronal/tree/d3ffe89c012756309844d1d5659fd6befdb0b062 . Deep methods and limitations: https://github.com/nazeeh111/chronal/blob/d3ffe89c012756309844d1d5659fd6befdb0b062/docs/METHOD.md . The repository's old examples/demo plan has a different source fingerprint and remains a historical record; this archive never changes or bypasses that guard.
