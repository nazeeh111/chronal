from pathlib import Path
import hashlib,json,sys
P=Path(__file__).resolve().parent
for n,h in json.loads((P/'SHA256SUMS.json').read_text()).items():
 assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
print('All archive byte hashes match')
if '--hashes-only' not in sys.argv:
 sys.path.insert(0,str(P))
 from chronal.artifacts import verify_bundle
 result=verify_bundle(P/'worked-run',replay=True)
 assert result['valid'] and result['replayed']==['development','holdout']
 print(json.dumps(result,indent=2))
